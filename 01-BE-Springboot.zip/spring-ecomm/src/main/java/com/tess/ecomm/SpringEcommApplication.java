package com.tess.ecomm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEcommApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringEcommApplication.class, args);
	}

}
