package com.tess.ecomm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEcommApplicationTests {

	@Test
	void contextLoads() {
	}

}
